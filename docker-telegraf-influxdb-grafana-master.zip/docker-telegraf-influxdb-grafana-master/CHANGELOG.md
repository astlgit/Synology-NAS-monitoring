Docker Telegraf InfluxDB Grafana image
-----------------------------------

## v1.0.0 (2019-01-09)

* Initial release

## v1.1.0 (2019-01-15)

* Some fixes

## v1.2.1 (2019-03-30)

* Grafana, Influxdb, Telegraf and Chronograf version upgrades

## v1.3.0 (2019-05-31)

* Grafana, Influxdb, Telegraf and Chronograf version upgrades
* Small configurations tuning

## v1.4.0 (2020-01-28)

* Upgrade Grafana, Influxdb, Telegraf, Chronograf and Nodesource versions

## v1.5.0 (2020-05-20)

* Upgrade Grafana, Influxdb, Telegraf, Chronograf and Nodesource and Ubuntu versions

## v1.6.0 (2020-10-31)

* Grafana, Influxdb, Telegraf, Chronograf versions bumped

## v1.7.0 (2020-12-16)

* Grafana, Influxdb, Telegraf, Chronograf versions bumped
